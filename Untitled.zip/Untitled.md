```python
import numpy as np
import pandas as pd
```


```python
match = pd.read_csv('matches.csv')
deliveries = pd.read_csv('deliveries.csv')
```


```python
match.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>Season</th>
      <th>city</th>
      <th>date</th>
      <th>team1</th>
      <th>team2</th>
      <th>toss_winner</th>
      <th>toss_decision</th>
      <th>result</th>
      <th>dl_applied</th>
      <th>winner</th>
      <th>win_by_runs</th>
      <th>win_by_wickets</th>
      <th>player_of_match</th>
      <th>venue</th>
      <th>umpire1</th>
      <th>umpire2</th>
      <th>umpire3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>IPL-2017</td>
      <td>Hyderabad</td>
      <td>05-04-2017</td>
      <td>Sunrisers Hyderabad</td>
      <td>Royal Challengers Bangalore</td>
      <td>Royal Challengers Bangalore</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Sunrisers Hyderabad</td>
      <td>35</td>
      <td>0</td>
      <td>Yuvraj Singh</td>
      <td>Rajiv Gandhi International Stadium, Uppal</td>
      <td>AY Dandekar</td>
      <td>NJ Llong</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>IPL-2017</td>
      <td>Pune</td>
      <td>06-04-2017</td>
      <td>Mumbai Indians</td>
      <td>Rising Pune Supergiant</td>
      <td>Rising Pune Supergiant</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Rising Pune Supergiant</td>
      <td>0</td>
      <td>7</td>
      <td>SPD Smith</td>
      <td>Maharashtra Cricket Association Stadium</td>
      <td>A Nand Kishore</td>
      <td>S Ravi</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>IPL-2017</td>
      <td>Rajkot</td>
      <td>07-04-2017</td>
      <td>Gujarat Lions</td>
      <td>Kolkata Knight Riders</td>
      <td>Kolkata Knight Riders</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Kolkata Knight Riders</td>
      <td>0</td>
      <td>10</td>
      <td>CA Lynn</td>
      <td>Saurashtra Cricket Association Stadium</td>
      <td>Nitin Menon</td>
      <td>CK Nandan</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>IPL-2017</td>
      <td>Indore</td>
      <td>08-04-2017</td>
      <td>Rising Pune Supergiant</td>
      <td>Kings XI Punjab</td>
      <td>Kings XI Punjab</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Kings XI Punjab</td>
      <td>0</td>
      <td>6</td>
      <td>GJ Maxwell</td>
      <td>Holkar Cricket Stadium</td>
      <td>AK Chaudhary</td>
      <td>C Shamshuddin</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>IPL-2017</td>
      <td>Bangalore</td>
      <td>08-04-2017</td>
      <td>Royal Challengers Bangalore</td>
      <td>Delhi Daredevils</td>
      <td>Royal Challengers Bangalore</td>
      <td>bat</td>
      <td>normal</td>
      <td>0</td>
      <td>Royal Challengers Bangalore</td>
      <td>15</td>
      <td>0</td>
      <td>KM Jadhav</td>
      <td>M Chinnaswamy Stadium</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
match.shape
```




    (756, 18)




```python
deliveries.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>match_id</th>
      <th>inning</th>
      <th>batting_team</th>
      <th>bowling_team</th>
      <th>over</th>
      <th>ball</th>
      <th>batsman</th>
      <th>non_striker</th>
      <th>bowler</th>
      <th>is_super_over</th>
      <th>...</th>
      <th>bye_runs</th>
      <th>legbye_runs</th>
      <th>noball_runs</th>
      <th>penalty_runs</th>
      <th>batsman_runs</th>
      <th>extra_runs</th>
      <th>total_runs</th>
      <th>player_dismissed</th>
      <th>dismissal_kind</th>
      <th>fielder</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>1</td>
      <td>Sunrisers Hyderabad</td>
      <td>Royal Challengers Bangalore</td>
      <td>1</td>
      <td>1</td>
      <td>DA Warner</td>
      <td>S Dhawan</td>
      <td>TS Mills</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1</td>
      <td>Sunrisers Hyderabad</td>
      <td>Royal Challengers Bangalore</td>
      <td>1</td>
      <td>2</td>
      <td>DA Warner</td>
      <td>S Dhawan</td>
      <td>TS Mills</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>1</td>
      <td>Sunrisers Hyderabad</td>
      <td>Royal Challengers Bangalore</td>
      <td>1</td>
      <td>3</td>
      <td>DA Warner</td>
      <td>S Dhawan</td>
      <td>TS Mills</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1</td>
      <td>Sunrisers Hyderabad</td>
      <td>Royal Challengers Bangalore</td>
      <td>1</td>
      <td>4</td>
      <td>DA Warner</td>
      <td>S Dhawan</td>
      <td>TS Mills</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>1</td>
      <td>Sunrisers Hyderabad</td>
      <td>Royal Challengers Bangalore</td>
      <td>1</td>
      <td>5</td>
      <td>DA Warner</td>
      <td>S Dhawan</td>
      <td>TS Mills</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 21 columns</p>
</div>




```python
total_score_df = deliveries.groupby(['match_id','inning']).sum()['total_runs'].reset_index()
```

    C:\Users\HP\AppData\Local\Temp\ipykernel_11756\307066490.py:1: FutureWarning: The default value of numeric_only in DataFrameGroupBy.sum is deprecated. In a future version, numeric_only will default to False. Either specify numeric_only or select only columns which should be valid for the function.
      total_score_df = deliveries.groupby(['match_id','inning']).sum()['total_runs'].reset_index()
    


```python
total_score_df = total_score_df[total_score_df['inning'] == 2]
```


```python
total_score_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>match_id</th>
      <th>inning</th>
      <th>total_runs</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>2</td>
      <td>172</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>2</td>
      <td>187</td>
    </tr>
    <tr>
      <th>5</th>
      <td>3</td>
      <td>2</td>
      <td>184</td>
    </tr>
    <tr>
      <th>7</th>
      <td>4</td>
      <td>2</td>
      <td>164</td>
    </tr>
    <tr>
      <th>9</th>
      <td>5</td>
      <td>2</td>
      <td>142</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1519</th>
      <td>11347</td>
      <td>2</td>
      <td>137</td>
    </tr>
    <tr>
      <th>1521</th>
      <td>11412</td>
      <td>2</td>
      <td>140</td>
    </tr>
    <tr>
      <th>1523</th>
      <td>11413</td>
      <td>2</td>
      <td>170</td>
    </tr>
    <tr>
      <th>1525</th>
      <td>11414</td>
      <td>2</td>
      <td>162</td>
    </tr>
    <tr>
      <th>1527</th>
      <td>11415</td>
      <td>2</td>
      <td>157</td>
    </tr>
  </tbody>
</table>
<p>754 rows × 3 columns</p>
</div>




```python
match_df = match.merge(total_score_df[['match_id','total_runs']],left_on='id',right_on='match_id')
```


```python
match_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>Season</th>
      <th>city</th>
      <th>date</th>
      <th>team1</th>
      <th>team2</th>
      <th>toss_winner</th>
      <th>toss_decision</th>
      <th>result</th>
      <th>dl_applied</th>
      <th>winner</th>
      <th>win_by_runs</th>
      <th>win_by_wickets</th>
      <th>player_of_match</th>
      <th>venue</th>
      <th>umpire1</th>
      <th>umpire2</th>
      <th>umpire3</th>
      <th>match_id</th>
      <th>total_runs</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>IPL-2017</td>
      <td>Hyderabad</td>
      <td>05-04-2017</td>
      <td>Sunrisers Hyderabad</td>
      <td>Royal Challengers Bangalore</td>
      <td>Royal Challengers Bangalore</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Sunrisers Hyderabad</td>
      <td>35</td>
      <td>0</td>
      <td>Yuvraj Singh</td>
      <td>Rajiv Gandhi International Stadium, Uppal</td>
      <td>AY Dandekar</td>
      <td>NJ Llong</td>
      <td>NaN</td>
      <td>1</td>
      <td>172</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>IPL-2017</td>
      <td>Pune</td>
      <td>06-04-2017</td>
      <td>Mumbai Indians</td>
      <td>Rising Pune Supergiant</td>
      <td>Rising Pune Supergiant</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Rising Pune Supergiant</td>
      <td>0</td>
      <td>7</td>
      <td>SPD Smith</td>
      <td>Maharashtra Cricket Association Stadium</td>
      <td>A Nand Kishore</td>
      <td>S Ravi</td>
      <td>NaN</td>
      <td>2</td>
      <td>187</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>IPL-2017</td>
      <td>Rajkot</td>
      <td>07-04-2017</td>
      <td>Gujarat Lions</td>
      <td>Kolkata Knight Riders</td>
      <td>Kolkata Knight Riders</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Kolkata Knight Riders</td>
      <td>0</td>
      <td>10</td>
      <td>CA Lynn</td>
      <td>Saurashtra Cricket Association Stadium</td>
      <td>Nitin Menon</td>
      <td>CK Nandan</td>
      <td>NaN</td>
      <td>3</td>
      <td>184</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>IPL-2017</td>
      <td>Indore</td>
      <td>08-04-2017</td>
      <td>Rising Pune Supergiant</td>
      <td>Kings XI Punjab</td>
      <td>Kings XI Punjab</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Kings XI Punjab</td>
      <td>0</td>
      <td>6</td>
      <td>GJ Maxwell</td>
      <td>Holkar Cricket Stadium</td>
      <td>AK Chaudhary</td>
      <td>C Shamshuddin</td>
      <td>NaN</td>
      <td>4</td>
      <td>164</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>IPL-2017</td>
      <td>Bangalore</td>
      <td>08-04-2017</td>
      <td>Royal Challengers Bangalore</td>
      <td>Delhi Daredevils</td>
      <td>Royal Challengers Bangalore</td>
      <td>bat</td>
      <td>normal</td>
      <td>0</td>
      <td>Royal Challengers Bangalore</td>
      <td>15</td>
      <td>0</td>
      <td>KM Jadhav</td>
      <td>M Chinnaswamy Stadium</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5</td>
      <td>142</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>749</th>
      <td>11347</td>
      <td>IPL-2019</td>
      <td>Mumbai</td>
      <td>05-05-2019</td>
      <td>Kolkata Knight Riders</td>
      <td>Mumbai Indians</td>
      <td>Mumbai Indians</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Mumbai Indians</td>
      <td>0</td>
      <td>9</td>
      <td>HH Pandya</td>
      <td>Wankhede Stadium</td>
      <td>Nanda Kishore</td>
      <td>O Nandan</td>
      <td>S Ravi</td>
      <td>11347</td>
      <td>137</td>
    </tr>
    <tr>
      <th>750</th>
      <td>11412</td>
      <td>IPL-2019</td>
      <td>Chennai</td>
      <td>07-05-2019</td>
      <td>Chennai Super Kings</td>
      <td>Mumbai Indians</td>
      <td>Chennai Super Kings</td>
      <td>bat</td>
      <td>normal</td>
      <td>0</td>
      <td>Mumbai Indians</td>
      <td>0</td>
      <td>6</td>
      <td>AS Yadav</td>
      <td>M. A. Chidambaram Stadium</td>
      <td>Nigel Llong</td>
      <td>Nitin Menon</td>
      <td>Ian Gould</td>
      <td>11412</td>
      <td>140</td>
    </tr>
    <tr>
      <th>751</th>
      <td>11413</td>
      <td>IPL-2019</td>
      <td>Visakhapatnam</td>
      <td>08-05-2019</td>
      <td>Sunrisers Hyderabad</td>
      <td>Delhi Capitals</td>
      <td>Delhi Capitals</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Delhi Capitals</td>
      <td>0</td>
      <td>2</td>
      <td>RR Pant</td>
      <td>ACA-VDCA Stadium</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>11413</td>
      <td>170</td>
    </tr>
    <tr>
      <th>752</th>
      <td>11414</td>
      <td>IPL-2019</td>
      <td>Visakhapatnam</td>
      <td>10-05-2019</td>
      <td>Delhi Capitals</td>
      <td>Chennai Super Kings</td>
      <td>Chennai Super Kings</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Chennai Super Kings</td>
      <td>0</td>
      <td>6</td>
      <td>F du Plessis</td>
      <td>ACA-VDCA Stadium</td>
      <td>Sundaram Ravi</td>
      <td>Bruce Oxenford</td>
      <td>Chettithody Shamshuddin</td>
      <td>11414</td>
      <td>162</td>
    </tr>
    <tr>
      <th>753</th>
      <td>11415</td>
      <td>IPL-2019</td>
      <td>Hyderabad</td>
      <td>12-05-2019</td>
      <td>Mumbai Indians</td>
      <td>Chennai Super Kings</td>
      <td>Mumbai Indians</td>
      <td>bat</td>
      <td>normal</td>
      <td>0</td>
      <td>Mumbai Indians</td>
      <td>1</td>
      <td>0</td>
      <td>JJ Bumrah</td>
      <td>Rajiv Gandhi Intl. Cricket Stadium</td>
      <td>Nitin Menon</td>
      <td>Ian Gould</td>
      <td>Nigel Llong</td>
      <td>11415</td>
      <td>157</td>
    </tr>
  </tbody>
</table>
<p>754 rows × 20 columns</p>
</div>




```python
match_df['team1'].unique()
```




    array(['Sunrisers Hyderabad', 'Mumbai Indians', 'Gujarat Lions',
           'Rising Pune Supergiant', 'Royal Challengers Bangalore',
           'Kolkata Knight Riders', 'Delhi Daredevils', 'Kings XI Punjab',
           'Chennai Super Kings', 'Rajasthan Royals', 'Deccan Chargers',
           'Kochi Tuskers Kerala', 'Pune Warriors', 'Rising Pune Supergiants',
           'Delhi Capitals'], dtype=object)




```python
teams = ['Sunrisers Hyderabad','Mumbai Indians','Royal Challengers Bangalore','Kolkata Knight Riders', 'Kings XI Punjab',
       'Chennai Super Kings', 'Rajasthan Royals','Delhi Capitals']
```


```python
match_df['team1'] = match_df['team1'].str.replace('Delhi Daredevils','Delhi Capitals')
match_df['team2'] = match_df['team1'].str.replace('Delhi Daredevils','Delhi Capitals')

match_df['team1'] = match_df['team1'].str.replace('Deccan Chargers','Sunrisers Hyderabad')
```


```python
match_df = match_df[match_df['team1'].isin(teams)]
match_df = match_df[match_df['team1'].isin(teams)]
```


```python
match_df.shape
```




    (698, 20)




```python
match_df = match_df[match_df['dl_applied'] == 0]
```


```python
match_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>Season</th>
      <th>city</th>
      <th>date</th>
      <th>team1</th>
      <th>team2</th>
      <th>toss_winner</th>
      <th>toss_decision</th>
      <th>result</th>
      <th>dl_applied</th>
      <th>winner</th>
      <th>win_by_runs</th>
      <th>win_by_wickets</th>
      <th>player_of_match</th>
      <th>venue</th>
      <th>umpire1</th>
      <th>umpire2</th>
      <th>umpire3</th>
      <th>match_id</th>
      <th>total_runs</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>IPL-2017</td>
      <td>Hyderabad</td>
      <td>05-04-2017</td>
      <td>Sunrisers Hyderabad</td>
      <td>Sunrisers Hyderabad</td>
      <td>Royal Challengers Bangalore</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Sunrisers Hyderabad</td>
      <td>35</td>
      <td>0</td>
      <td>Yuvraj Singh</td>
      <td>Rajiv Gandhi International Stadium, Uppal</td>
      <td>AY Dandekar</td>
      <td>NJ Llong</td>
      <td>NaN</td>
      <td>1</td>
      <td>172</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>IPL-2017</td>
      <td>Pune</td>
      <td>06-04-2017</td>
      <td>Mumbai Indians</td>
      <td>Mumbai Indians</td>
      <td>Rising Pune Supergiant</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Rising Pune Supergiant</td>
      <td>0</td>
      <td>7</td>
      <td>SPD Smith</td>
      <td>Maharashtra Cricket Association Stadium</td>
      <td>A Nand Kishore</td>
      <td>S Ravi</td>
      <td>NaN</td>
      <td>2</td>
      <td>187</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>IPL-2017</td>
      <td>Bangalore</td>
      <td>08-04-2017</td>
      <td>Royal Challengers Bangalore</td>
      <td>Royal Challengers Bangalore</td>
      <td>Royal Challengers Bangalore</td>
      <td>bat</td>
      <td>normal</td>
      <td>0</td>
      <td>Royal Challengers Bangalore</td>
      <td>15</td>
      <td>0</td>
      <td>KM Jadhav</td>
      <td>M Chinnaswamy Stadium</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5</td>
      <td>142</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>IPL-2017</td>
      <td>Mumbai</td>
      <td>09-04-2017</td>
      <td>Kolkata Knight Riders</td>
      <td>Kolkata Knight Riders</td>
      <td>Mumbai Indians</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Mumbai Indians</td>
      <td>0</td>
      <td>4</td>
      <td>N Rana</td>
      <td>Wankhede Stadium</td>
      <td>Nitin Menon</td>
      <td>CK Nandan</td>
      <td>NaN</td>
      <td>7</td>
      <td>180</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>IPL-2017</td>
      <td>Indore</td>
      <td>10-04-2017</td>
      <td>Royal Challengers Bangalore</td>
      <td>Royal Challengers Bangalore</td>
      <td>Royal Challengers Bangalore</td>
      <td>bat</td>
      <td>normal</td>
      <td>0</td>
      <td>Kings XI Punjab</td>
      <td>0</td>
      <td>8</td>
      <td>AR Patel</td>
      <td>Holkar Cricket Stadium</td>
      <td>AK Chaudhary</td>
      <td>C Shamshuddin</td>
      <td>NaN</td>
      <td>8</td>
      <td>150</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>749</th>
      <td>11347</td>
      <td>IPL-2019</td>
      <td>Mumbai</td>
      <td>05-05-2019</td>
      <td>Kolkata Knight Riders</td>
      <td>Kolkata Knight Riders</td>
      <td>Mumbai Indians</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Mumbai Indians</td>
      <td>0</td>
      <td>9</td>
      <td>HH Pandya</td>
      <td>Wankhede Stadium</td>
      <td>Nanda Kishore</td>
      <td>O Nandan</td>
      <td>S Ravi</td>
      <td>11347</td>
      <td>137</td>
    </tr>
    <tr>
      <th>750</th>
      <td>11412</td>
      <td>IPL-2019</td>
      <td>Chennai</td>
      <td>07-05-2019</td>
      <td>Chennai Super Kings</td>
      <td>Chennai Super Kings</td>
      <td>Chennai Super Kings</td>
      <td>bat</td>
      <td>normal</td>
      <td>0</td>
      <td>Mumbai Indians</td>
      <td>0</td>
      <td>6</td>
      <td>AS Yadav</td>
      <td>M. A. Chidambaram Stadium</td>
      <td>Nigel Llong</td>
      <td>Nitin Menon</td>
      <td>Ian Gould</td>
      <td>11412</td>
      <td>140</td>
    </tr>
    <tr>
      <th>751</th>
      <td>11413</td>
      <td>IPL-2019</td>
      <td>Visakhapatnam</td>
      <td>08-05-2019</td>
      <td>Sunrisers Hyderabad</td>
      <td>Sunrisers Hyderabad</td>
      <td>Delhi Capitals</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Delhi Capitals</td>
      <td>0</td>
      <td>2</td>
      <td>RR Pant</td>
      <td>ACA-VDCA Stadium</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>11413</td>
      <td>170</td>
    </tr>
    <tr>
      <th>752</th>
      <td>11414</td>
      <td>IPL-2019</td>
      <td>Visakhapatnam</td>
      <td>10-05-2019</td>
      <td>Delhi Capitals</td>
      <td>Delhi Capitals</td>
      <td>Chennai Super Kings</td>
      <td>field</td>
      <td>normal</td>
      <td>0</td>
      <td>Chennai Super Kings</td>
      <td>0</td>
      <td>6</td>
      <td>F du Plessis</td>
      <td>ACA-VDCA Stadium</td>
      <td>Sundaram Ravi</td>
      <td>Bruce Oxenford</td>
      <td>Chettithody Shamshuddin</td>
      <td>11414</td>
      <td>162</td>
    </tr>
    <tr>
      <th>753</th>
      <td>11415</td>
      <td>IPL-2019</td>
      <td>Hyderabad</td>
      <td>12-05-2019</td>
      <td>Mumbai Indians</td>
      <td>Mumbai Indians</td>
      <td>Mumbai Indians</td>
      <td>bat</td>
      <td>normal</td>
      <td>0</td>
      <td>Mumbai Indians</td>
      <td>1</td>
      <td>0</td>
      <td>JJ Bumrah</td>
      <td>Rajiv Gandhi Intl. Cricket Stadium</td>
      <td>Nitin Menon</td>
      <td>Ian Gould</td>
      <td>Nigel Llong</td>
      <td>11415</td>
      <td>157</td>
    </tr>
  </tbody>
</table>
<p>680 rows × 20 columns</p>
</div>




```python
match_df = match_df[['match_id','city','winner','total_runs']]
```


```python
deliveries_df = match_df.merge(deliveries,on='match_id')
```


```python
deliveries_df = deliveries_df[deliveries_df['inning'] == 2]
```


```python
deliveries_df.shape
```




    (78749, 24)




```python
deliveries_df['current_score'] = deliveries_df.groupby('match_id').cumsum()['total_runs_y']
```

    C:\Users\HP\AppData\Local\Temp\ipykernel_11756\3612791721.py:1: FutureWarning: The default value of numeric_only in DataFrameGroupBy.cumsum is deprecated. In a future version, numeric_only will default to False. Either specify numeric_only or select only columns which should be valid for the function.
      deliveries_df['current_score'] = deliveries_df.groupby('match_id').cumsum()['total_runs_y']
    


```python
deliveries_df['runs_left'] = deliveries_df['total_runs_x'] - deliveries_df['current_score']
```


```python
deliveries_df['balls_left'] = 126 - (deliveries_df['over']*6 + deliveries_df['ball'])
```


```python
deliveries_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>match_id</th>
      <th>city</th>
      <th>winner</th>
      <th>total_runs_x</th>
      <th>inning</th>
      <th>batting_team</th>
      <th>bowling_team</th>
      <th>over</th>
      <th>ball</th>
      <th>batsman</th>
      <th>...</th>
      <th>penalty_runs</th>
      <th>batsman_runs</th>
      <th>extra_runs</th>
      <th>total_runs_y</th>
      <th>player_dismissed</th>
      <th>dismissal_kind</th>
      <th>fielder</th>
      <th>current_score</th>
      <th>runs_left</th>
      <th>balls_left</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>125</th>
      <td>1</td>
      <td>Hyderabad</td>
      <td>Sunrisers Hyderabad</td>
      <td>172</td>
      <td>2</td>
      <td>Royal Challengers Bangalore</td>
      <td>Sunrisers Hyderabad</td>
      <td>1</td>
      <td>1</td>
      <td>CH Gayle</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>171</td>
      <td>119</td>
    </tr>
    <tr>
      <th>126</th>
      <td>1</td>
      <td>Hyderabad</td>
      <td>Sunrisers Hyderabad</td>
      <td>172</td>
      <td>2</td>
      <td>Royal Challengers Bangalore</td>
      <td>Sunrisers Hyderabad</td>
      <td>1</td>
      <td>2</td>
      <td>Mandeep Singh</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>171</td>
      <td>118</td>
    </tr>
    <tr>
      <th>127</th>
      <td>1</td>
      <td>Hyderabad</td>
      <td>Sunrisers Hyderabad</td>
      <td>172</td>
      <td>2</td>
      <td>Royal Challengers Bangalore</td>
      <td>Sunrisers Hyderabad</td>
      <td>1</td>
      <td>3</td>
      <td>Mandeep Singh</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>171</td>
      <td>117</td>
    </tr>
    <tr>
      <th>128</th>
      <td>1</td>
      <td>Hyderabad</td>
      <td>Sunrisers Hyderabad</td>
      <td>172</td>
      <td>2</td>
      <td>Royal Challengers Bangalore</td>
      <td>Sunrisers Hyderabad</td>
      <td>1</td>
      <td>4</td>
      <td>Mandeep Singh</td>
      <td>...</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3</td>
      <td>169</td>
      <td>116</td>
    </tr>
    <tr>
      <th>129</th>
      <td>1</td>
      <td>Hyderabad</td>
      <td>Sunrisers Hyderabad</td>
      <td>172</td>
      <td>2</td>
      <td>Royal Challengers Bangalore</td>
      <td>Sunrisers Hyderabad</td>
      <td>1</td>
      <td>5</td>
      <td>Mandeep Singh</td>
      <td>...</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>7</td>
      <td>165</td>
      <td>115</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>162546</th>
      <td>11415</td>
      <td>Hyderabad</td>
      <td>Mumbai Indians</td>
      <td>157</td>
      <td>2</td>
      <td>Chennai Super Kings</td>
      <td>Mumbai Indians</td>
      <td>20</td>
      <td>2</td>
      <td>RA Jadeja</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>152</td>
      <td>5</td>
      <td>4</td>
    </tr>
    <tr>
      <th>162547</th>
      <td>11415</td>
      <td>Hyderabad</td>
      <td>Mumbai Indians</td>
      <td>157</td>
      <td>2</td>
      <td>Chennai Super Kings</td>
      <td>Mumbai Indians</td>
      <td>20</td>
      <td>3</td>
      <td>SR Watson</td>
      <td>...</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>154</td>
      <td>3</td>
      <td>3</td>
    </tr>
    <tr>
      <th>162548</th>
      <td>11415</td>
      <td>Hyderabad</td>
      <td>Mumbai Indians</td>
      <td>157</td>
      <td>2</td>
      <td>Chennai Super Kings</td>
      <td>Mumbai Indians</td>
      <td>20</td>
      <td>4</td>
      <td>SR Watson</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>SR Watson</td>
      <td>run out</td>
      <td>KH Pandya</td>
      <td>155</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>162549</th>
      <td>11415</td>
      <td>Hyderabad</td>
      <td>Mumbai Indians</td>
      <td>157</td>
      <td>2</td>
      <td>Chennai Super Kings</td>
      <td>Mumbai Indians</td>
      <td>20</td>
      <td>5</td>
      <td>SN Thakur</td>
      <td>...</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>157</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>162550</th>
      <td>11415</td>
      <td>Hyderabad</td>
      <td>Mumbai Indians</td>
      <td>157</td>
      <td>2</td>
      <td>Chennai Super Kings</td>
      <td>Mumbai Indians</td>
      <td>20</td>
      <td>6</td>
      <td>SN Thakur</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>SN Thakur</td>
      <td>lbw</td>
      <td>NaN</td>
      <td>157</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>78749 rows × 27 columns</p>
</div>




```python
deliveries_df['player_dismissed'] = deliveries_df['player_dismissed'].fillna("0")
deliveries_df['player_dismissed'] = deliveries_df['player_dismissed'].apply(lambda x:x if x == "0" else "1")
deliveries_df['player_dismissed'] = deliveries_df['player_dismissed'].astype('int')
wickets = deliveries_df.groupby('match_id').cumsum()['player_dismissed'].values
deliveries_df['wickets'] = 10 - wickets
deliveries_df.head()
```

    C:\Users\HP\AppData\Local\Temp\ipykernel_11756\2048352233.py:4: FutureWarning: The default value of numeric_only in DataFrameGroupBy.cumsum is deprecated. In a future version, numeric_only will default to False. Either specify numeric_only or select only columns which should be valid for the function.
      wickets = deliveries_df.groupby('match_id').cumsum()['player_dismissed'].values
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>match_id</th>
      <th>city</th>
      <th>winner</th>
      <th>total_runs_x</th>
      <th>inning</th>
      <th>batting_team</th>
      <th>bowling_team</th>
      <th>over</th>
      <th>ball</th>
      <th>batsman</th>
      <th>...</th>
      <th>batsman_runs</th>
      <th>extra_runs</th>
      <th>total_runs_y</th>
      <th>player_dismissed</th>
      <th>dismissal_kind</th>
      <th>fielder</th>
      <th>current_score</th>
      <th>runs_left</th>
      <th>balls_left</th>
      <th>wickets</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>125</th>
      <td>1</td>
      <td>Hyderabad</td>
      <td>Sunrisers Hyderabad</td>
      <td>172</td>
      <td>2</td>
      <td>Royal Challengers Bangalore</td>
      <td>Sunrisers Hyderabad</td>
      <td>1</td>
      <td>1</td>
      <td>CH Gayle</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>171</td>
      <td>119</td>
      <td>10</td>
    </tr>
    <tr>
      <th>126</th>
      <td>1</td>
      <td>Hyderabad</td>
      <td>Sunrisers Hyderabad</td>
      <td>172</td>
      <td>2</td>
      <td>Royal Challengers Bangalore</td>
      <td>Sunrisers Hyderabad</td>
      <td>1</td>
      <td>2</td>
      <td>Mandeep Singh</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>171</td>
      <td>118</td>
      <td>10</td>
    </tr>
    <tr>
      <th>127</th>
      <td>1</td>
      <td>Hyderabad</td>
      <td>Sunrisers Hyderabad</td>
      <td>172</td>
      <td>2</td>
      <td>Royal Challengers Bangalore</td>
      <td>Sunrisers Hyderabad</td>
      <td>1</td>
      <td>3</td>
      <td>Mandeep Singh</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>171</td>
      <td>117</td>
      <td>10</td>
    </tr>
    <tr>
      <th>128</th>
      <td>1</td>
      <td>Hyderabad</td>
      <td>Sunrisers Hyderabad</td>
      <td>172</td>
      <td>2</td>
      <td>Royal Challengers Bangalore</td>
      <td>Sunrisers Hyderabad</td>
      <td>1</td>
      <td>4</td>
      <td>Mandeep Singh</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3</td>
      <td>169</td>
      <td>116</td>
      <td>10</td>
    </tr>
    <tr>
      <th>129</th>
      <td>1</td>
      <td>Hyderabad</td>
      <td>Sunrisers Hyderabad</td>
      <td>172</td>
      <td>2</td>
      <td>Royal Challengers Bangalore</td>
      <td>Sunrisers Hyderabad</td>
      <td>1</td>
      <td>5</td>
      <td>Mandeep Singh</td>
      <td>...</td>
      <td>4</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>7</td>
      <td>165</td>
      <td>115</td>
      <td>10</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 28 columns</p>
</div>




```python
deliveries_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>match_id</th>
      <th>city</th>
      <th>winner</th>
      <th>total_runs_x</th>
      <th>inning</th>
      <th>batting_team</th>
      <th>bowling_team</th>
      <th>over</th>
      <th>ball</th>
      <th>batsman</th>
      <th>...</th>
      <th>batsman_runs</th>
      <th>extra_runs</th>
      <th>total_runs_y</th>
      <th>player_dismissed</th>
      <th>dismissal_kind</th>
      <th>fielder</th>
      <th>current_score</th>
      <th>runs_left</th>
      <th>balls_left</th>
      <th>wickets</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>125</th>
      <td>1</td>
      <td>Hyderabad</td>
      <td>Sunrisers Hyderabad</td>
      <td>172</td>
      <td>2</td>
      <td>Royal Challengers Bangalore</td>
      <td>Sunrisers Hyderabad</td>
      <td>1</td>
      <td>1</td>
      <td>CH Gayle</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>171</td>
      <td>119</td>
      <td>10</td>
    </tr>
    <tr>
      <th>126</th>
      <td>1</td>
      <td>Hyderabad</td>
      <td>Sunrisers Hyderabad</td>
      <td>172</td>
      <td>2</td>
      <td>Royal Challengers Bangalore</td>
      <td>Sunrisers Hyderabad</td>
      <td>1</td>
      <td>2</td>
      <td>Mandeep Singh</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>171</td>
      <td>118</td>
      <td>10</td>
    </tr>
    <tr>
      <th>127</th>
      <td>1</td>
      <td>Hyderabad</td>
      <td>Sunrisers Hyderabad</td>
      <td>172</td>
      <td>2</td>
      <td>Royal Challengers Bangalore</td>
      <td>Sunrisers Hyderabad</td>
      <td>1</td>
      <td>3</td>
      <td>Mandeep Singh</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>171</td>
      <td>117</td>
      <td>10</td>
    </tr>
    <tr>
      <th>128</th>
      <td>1</td>
      <td>Hyderabad</td>
      <td>Sunrisers Hyderabad</td>
      <td>172</td>
      <td>2</td>
      <td>Royal Challengers Bangalore</td>
      <td>Sunrisers Hyderabad</td>
      <td>1</td>
      <td>4</td>
      <td>Mandeep Singh</td>
      <td>...</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3</td>
      <td>169</td>
      <td>116</td>
      <td>10</td>
    </tr>
    <tr>
      <th>129</th>
      <td>1</td>
      <td>Hyderabad</td>
      <td>Sunrisers Hyderabad</td>
      <td>172</td>
      <td>2</td>
      <td>Royal Challengers Bangalore</td>
      <td>Sunrisers Hyderabad</td>
      <td>1</td>
      <td>5</td>
      <td>Mandeep Singh</td>
      <td>...</td>
      <td>4</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>7</td>
      <td>165</td>
      <td>115</td>
      <td>10</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 28 columns</p>
</div>




```python
deliveries_df['crr'] = (deliveries_df['current_score']*6)/(120 - deliveries_df['balls_left'])
```


```python
deliveries_df['rrr'] = (deliveries_df['runs_left']*6)/deliveries_df['balls_left']
```


```python
def result(row):
    return 1 if row['batting_team'] == row['winner'] else 0
```


```python
deliveries_df['result'] = deliveries_df.apply(result,axis=1)
```


```python
final_df = deliveries_df[['batting_team','bowling_team','city','runs_left','balls_left','wickets','total_runs_x','crr','rrr','result']]
```


```python
final_df = final_df.sample(final_df.shape[0])
```


```python
final_df.sample()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>batting_team</th>
      <th>bowling_team</th>
      <th>city</th>
      <th>runs_left</th>
      <th>balls_left</th>
      <th>wickets</th>
      <th>total_runs_x</th>
      <th>crr</th>
      <th>rrr</th>
      <th>result</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>92528</th>
      <td>Pune Warriors</td>
      <td>Kolkata Knight Riders</td>
      <td>Pune</td>
      <td>67</td>
      <td>77</td>
      <td>7</td>
      <td>106</td>
      <td>5.44186</td>
      <td>5.220779</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
final_df.dropna(inplace=True)
```


```python
final_df = final_df[final_df['balls_left'] != 0]
```


```python
X = final_df.iloc[:,:-1]
y = final_df.iloc[:,-1]
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state=1)
```


```python
X_train
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>batting_team</th>
      <th>bowling_team</th>
      <th>city</th>
      <th>runs_left</th>
      <th>balls_left</th>
      <th>wickets</th>
      <th>total_runs_x</th>
      <th>crr</th>
      <th>rrr</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>135333</th>
      <td>Sunrisers Hyderabad</td>
      <td>Rajasthan Royals</td>
      <td>Hyderabad</td>
      <td>109</td>
      <td>101</td>
      <td>9</td>
      <td>135</td>
      <td>8.210526</td>
      <td>6.475248</td>
    </tr>
    <tr>
      <th>1881</th>
      <td>Kolkata Knight Riders</td>
      <td>Kings XI Punjab</td>
      <td>Kolkata</td>
      <td>42</td>
      <td>47</td>
      <td>8</td>
      <td>171</td>
      <td>10.602740</td>
      <td>5.361702</td>
    </tr>
    <tr>
      <th>52478</th>
      <td>Kings XI Punjab</td>
      <td>Chennai Super Kings</td>
      <td>Chandigarh</td>
      <td>28</td>
      <td>20</td>
      <td>6</td>
      <td>193</td>
      <td>9.900000</td>
      <td>8.400000</td>
    </tr>
    <tr>
      <th>132245</th>
      <td>Delhi Daredevils</td>
      <td>Mumbai Indians</td>
      <td>Visakhapatnam</td>
      <td>44</td>
      <td>56</td>
      <td>6</td>
      <td>126</td>
      <td>7.687500</td>
      <td>4.714286</td>
    </tr>
    <tr>
      <th>90211</th>
      <td>Pune Warriors</td>
      <td>Royal Challengers Bangalore</td>
      <td>Pune</td>
      <td>86</td>
      <td>50</td>
      <td>6</td>
      <td>170</td>
      <td>7.200000</td>
      <td>10.320000</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>154954</th>
      <td>Royal Challengers Bangalore</td>
      <td>Kings XI Punjab</td>
      <td>Mohali</td>
      <td>102</td>
      <td>74</td>
      <td>9</td>
      <td>175</td>
      <td>9.521739</td>
      <td>8.270270</td>
    </tr>
    <tr>
      <th>39688</th>
      <td>Delhi Daredevils</td>
      <td>Deccan Chargers</td>
      <td>Cuttack</td>
      <td>69</td>
      <td>52</td>
      <td>8</td>
      <td>161</td>
      <td>8.117647</td>
      <td>7.961538</td>
    </tr>
    <tr>
      <th>130523</th>
      <td>Kings XI Punjab</td>
      <td>Royal Challengers Bangalore</td>
      <td>Chandigarh</td>
      <td>143</td>
      <td>97</td>
      <td>10</td>
      <td>174</td>
      <td>8.086957</td>
      <td>8.845361</td>
    </tr>
    <tr>
      <th>54036</th>
      <td>Delhi Daredevils</td>
      <td>Deccan Chargers</td>
      <td>Delhi</td>
      <td>126</td>
      <td>104</td>
      <td>10</td>
      <td>152</td>
      <td>9.750000</td>
      <td>7.269231</td>
    </tr>
    <tr>
      <th>38065</th>
      <td>Kolkata Knight Riders</td>
      <td>Chennai Super Kings</td>
      <td>Kolkata</td>
      <td>27</td>
      <td>39</td>
      <td>2</td>
      <td>109</td>
      <td>6.074074</td>
      <td>4.153846</td>
    </tr>
  </tbody>
</table>
<p>62120 rows × 9 columns</p>
</div>




```python
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
trf = ColumnTransformer([
    ('trf',OneHotEncoder(sparse=False,drop='first'),['batting_team','bowling_team','city'])]
    ,remainder='passthrough')
```


```python
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
```


```python
pipe = Pipeline(steps=[
    ('step1',trf),('step2',LogisticRegression(solver='liblinear'))])
```


```python
pipe.fit(X_train,y_train)
```

    C:\Users\HP\anaconda3\lib\site-packages\sklearn\preprocessing\_encoders.py:828: FutureWarning: `sparse` was renamed to `sparse_output` in version 1.2 and will be removed in 1.4. `sparse_output` is ignored unless you leave `sparse` to its default value.
      warnings.warn(
    




<style>#sk-container-id-1 {color: black;background-color: white;}#sk-container-id-1 pre{padding: 0;}#sk-container-id-1 div.sk-toggleable {background-color: white;}#sk-container-id-1 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-1 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-1 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-1 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-1 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-1 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-1 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-1 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-1 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-1 div.sk-item {position: relative;z-index: 1;}#sk-container-id-1 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-1 div.sk-item::before, #sk-container-id-1 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-1 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-1 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-1 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-1 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-1 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-1 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-1 div.sk-label-container {text-align: center;}#sk-container-id-1 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-1 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>Pipeline(steps=[(&#x27;step1&#x27;,
                 ColumnTransformer(remainder=&#x27;passthrough&#x27;,
                                   transformers=[(&#x27;trf&#x27;,
                                                  OneHotEncoder(drop=&#x27;first&#x27;,
                                                                sparse=False),
                                                  [&#x27;batting_team&#x27;,
                                                   &#x27;bowling_team&#x27;, &#x27;city&#x27;])])),
                (&#x27;step2&#x27;, LogisticRegression(solver=&#x27;liblinear&#x27;))])</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" ><label for="sk-estimator-id-1" class="sk-toggleable__label sk-toggleable__label-arrow">Pipeline</label><div class="sk-toggleable__content"><pre>Pipeline(steps=[(&#x27;step1&#x27;,
                 ColumnTransformer(remainder=&#x27;passthrough&#x27;,
                                   transformers=[(&#x27;trf&#x27;,
                                                  OneHotEncoder(drop=&#x27;first&#x27;,
                                                                sparse=False),
                                                  [&#x27;batting_team&#x27;,
                                                   &#x27;bowling_team&#x27;, &#x27;city&#x27;])])),
                (&#x27;step2&#x27;, LogisticRegression(solver=&#x27;liblinear&#x27;))])</pre></div></div></div><div class="sk-serial"><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-2" type="checkbox" ><label for="sk-estimator-id-2" class="sk-toggleable__label sk-toggleable__label-arrow">step1: ColumnTransformer</label><div class="sk-toggleable__content"><pre>ColumnTransformer(remainder=&#x27;passthrough&#x27;,
                  transformers=[(&#x27;trf&#x27;,
                                 OneHotEncoder(drop=&#x27;first&#x27;, sparse=False),
                                 [&#x27;batting_team&#x27;, &#x27;bowling_team&#x27;, &#x27;city&#x27;])])</pre></div></div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-3" type="checkbox" ><label for="sk-estimator-id-3" class="sk-toggleable__label sk-toggleable__label-arrow">trf</label><div class="sk-toggleable__content"><pre>[&#x27;batting_team&#x27;, &#x27;bowling_team&#x27;, &#x27;city&#x27;]</pre></div></div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-4" type="checkbox" ><label for="sk-estimator-id-4" class="sk-toggleable__label sk-toggleable__label-arrow">OneHotEncoder</label><div class="sk-toggleable__content"><pre>OneHotEncoder(drop=&#x27;first&#x27;, sparse=False)</pre></div></div></div></div></div></div><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-5" type="checkbox" ><label for="sk-estimator-id-5" class="sk-toggleable__label sk-toggleable__label-arrow">remainder</label><div class="sk-toggleable__content"><pre>[&#x27;runs_left&#x27;, &#x27;balls_left&#x27;, &#x27;wickets&#x27;, &#x27;total_runs_x&#x27;, &#x27;crr&#x27;, &#x27;rrr&#x27;]</pre></div></div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-6" type="checkbox" ><label for="sk-estimator-id-6" class="sk-toggleable__label sk-toggleable__label-arrow">passthrough</label><div class="sk-toggleable__content"><pre>passthrough</pre></div></div></div></div></div></div></div></div><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-7" type="checkbox" ><label for="sk-estimator-id-7" class="sk-toggleable__label sk-toggleable__label-arrow">LogisticRegression</label><div class="sk-toggleable__content"><pre>LogisticRegression(solver=&#x27;liblinear&#x27;)</pre></div></div></div></div></div></div></div>




```python
X_train.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>runs_left</th>
      <th>balls_left</th>
      <th>wickets</th>
      <th>total_runs_x</th>
      <th>crr</th>
      <th>rrr</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>62120.000000</td>
      <td>62120.000000</td>
      <td>62120.000000</td>
      <td>62120.00000</td>
      <td>62120.000000</td>
      <td>62120.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>79.388571</td>
      <td>62.846410</td>
      <td>7.535029</td>
      <td>152.36209</td>
      <td>7.430971</td>
      <td>7.653729</td>
    </tr>
    <tr>
      <th>std</th>
      <td>47.412234</td>
      <td>33.273335</td>
      <td>2.125423</td>
      <td>28.66815</td>
      <td>2.273314</td>
      <td>2.910451</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>-2.000000</td>
      <td>0.000000</td>
      <td>2.00000</td>
      <td>0.000000</td>
      <td>-36.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>40.000000</td>
      <td>35.000000</td>
      <td>6.000000</td>
      <td>135.00000</td>
      <td>6.244898</td>
      <td>6.116225</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>77.000000</td>
      <td>64.000000</td>
      <td>8.000000</td>
      <td>153.00000</td>
      <td>7.465116</td>
      <td>7.666667</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>115.000000</td>
      <td>92.000000</td>
      <td>9.000000</td>
      <td>172.00000</td>
      <td>8.688039</td>
      <td>9.148515</td>
    </tr>
    <tr>
      <th>max</th>
      <td>223.000000</td>
      <td>119.000000</td>
      <td>10.000000</td>
      <td>223.00000</td>
      <td>42.000000</td>
      <td>72.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
y_pred = pipe.predict(X_test)
```


```python
from sklearn.metrics import accuracy_score
accuracy_score(y_test,y_pred)
```




    0.7302640051513201




```python
pipe.predict_proba(X_test)[10]
```




    array([0.92242219, 0.07757781])




```python
def match_progression(x_df,match_id,pipe):
    match = x_df[x_df['match_id'] == match_id]
    match = match[(match['ball'] == 6)]
    temp_df = match[['batting_team','bowling_team','city','runs_left','balls_left','wickets','total_runs_x','crr','rrr']].dropna()
    temp_df = temp_df[temp_df['balls_left'] != 0]
    result = pipe.predict_proba(temp_df)
    temp_df['lose'] = np.round(result.T[0]*100,1)
    temp_df['win'] = np.round(result.T[1]*100,1)
    temp_df['end_of_over'] = range(1,temp_df.shape[0]+1)
    
    target = temp_df['total_runs_x'].values[0]
    runs = list(temp_df['runs_left'].values)
    new_runs = runs[:]
    runs.insert(0,target)
    temp_df['runs_after_over'] = np.array(runs)[:-1] - np.array(new_runs)
    wickets = list(temp_df['wickets'].values)
    new_wickets = wickets[:]
    new_wickets.insert(0,10)
    wickets.append(0)
    w = np.array(wickets)
    nw = np.array(new_wickets)
    temp_df['wickets_in_over'] = (nw - w)[0:temp_df.shape[0]]
    
    print("Target-",target)
    temp_df = temp_df[['end_of_over','runs_after_over','wickets_in_over','lose','win']]
    return temp_df,target
```


```python
temp_df,target = match_progression(deliveries_df,74,pipe)
temp_df
```

    Target- 165
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>end_of_over</th>
      <th>runs_after_over</th>
      <th>wickets_in_over</th>
      <th>lose</th>
      <th>win</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>13265</th>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>44.2</td>
      <td>55.8</td>
    </tr>
    <tr>
      <th>13273</th>
      <td>2</td>
      <td>8</td>
      <td>0</td>
      <td>38.3</td>
      <td>61.7</td>
    </tr>
    <tr>
      <th>13279</th>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>34.6</td>
      <td>65.4</td>
    </tr>
    <tr>
      <th>13285</th>
      <td>4</td>
      <td>7</td>
      <td>1</td>
      <td>50.1</td>
      <td>49.9</td>
    </tr>
    <tr>
      <th>13291</th>
      <td>5</td>
      <td>12</td>
      <td>0</td>
      <td>43.7</td>
      <td>56.3</td>
    </tr>
    <tr>
      <th>13297</th>
      <td>6</td>
      <td>13</td>
      <td>0</td>
      <td>37.4</td>
      <td>62.6</td>
    </tr>
    <tr>
      <th>13303</th>
      <td>7</td>
      <td>9</td>
      <td>0</td>
      <td>32.3</td>
      <td>67.7</td>
    </tr>
    <tr>
      <th>13311</th>
      <td>8</td>
      <td>15</td>
      <td>0</td>
      <td>26.6</td>
      <td>73.4</td>
    </tr>
    <tr>
      <th>13317</th>
      <td>9</td>
      <td>7</td>
      <td>0</td>
      <td>22.7</td>
      <td>77.3</td>
    </tr>
    <tr>
      <th>13324</th>
      <td>10</td>
      <td>17</td>
      <td>0</td>
      <td>18.0</td>
      <td>82.0</td>
    </tr>
    <tr>
      <th>13330</th>
      <td>11</td>
      <td>9</td>
      <td>1</td>
      <td>29.2</td>
      <td>70.8</td>
    </tr>
    <tr>
      <th>13336</th>
      <td>12</td>
      <td>9</td>
      <td>0</td>
      <td>24.6</td>
      <td>75.4</td>
    </tr>
    <tr>
      <th>13342</th>
      <td>13</td>
      <td>8</td>
      <td>0</td>
      <td>20.7</td>
      <td>79.3</td>
    </tr>
    <tr>
      <th>13348</th>
      <td>14</td>
      <td>8</td>
      <td>0</td>
      <td>17.2</td>
      <td>82.8</td>
    </tr>
    <tr>
      <th>13354</th>
      <td>15</td>
      <td>5</td>
      <td>1</td>
      <td>28.7</td>
      <td>71.3</td>
    </tr>
    <tr>
      <th>13361</th>
      <td>16</td>
      <td>8</td>
      <td>1</td>
      <td>43.0</td>
      <td>57.0</td>
    </tr>
    <tr>
      <th>13367</th>
      <td>17</td>
      <td>8</td>
      <td>2</td>
      <td>76.8</td>
      <td>23.2</td>
    </tr>
    <tr>
      <th>13373</th>
      <td>18</td>
      <td>6</td>
      <td>1</td>
      <td>86.3</td>
      <td>13.7</td>
    </tr>
    <tr>
      <th>13379</th>
      <td>19</td>
      <td>8</td>
      <td>2</td>
      <td>96.3</td>
      <td>3.7</td>
    </tr>
  </tbody>
</table>
</div>




```python
import matplotlib.pyplot as plt
plt.figure(figsize=(18,8))
plt.plot(temp_df['end_of_over'],temp_df['wickets_in_over'],color='yellow',linewidth=3)
plt.plot(temp_df['end_of_over'],temp_df['win'],color='#00a65a',linewidth=4)
plt.plot(temp_df['end_of_over'],temp_df['lose'],color='red',linewidth=4)
plt.bar(temp_df['end_of_over'],temp_df['runs_after_over'])
plt.title('Target-' + str(target))
```




    Text(0.5, 1.0, 'Target-165')




    
![png](output_48_1.png)
    



```python
teams
```




    ['Sunrisers Hyderabad',
     'Mumbai Indians',
     'Royal Challengers Bangalore',
     'Kolkata Knight Riders',
     'Kings XI Punjab',
     'Chennai Super Kings',
     'Rajasthan Royals',
     'Delhi Capitals']




```python
deliveries_df['city'].unique()
```




    array(['Hyderabad', 'Pune', 'Bangalore', 'Mumbai', 'Indore', 'Kolkata',
           'Delhi', 'Rajkot', 'Chandigarh', 'Jaipur', 'Chennai', 'Cape Town',
           'Port Elizabeth', 'Durban', 'Centurion', 'East London',
           'Johannesburg', 'Kimberley', 'Bloemfontein', 'Ahmedabad',
           'Cuttack', 'Nagpur', 'Dharamsala', 'Kochi', 'Visakhapatnam',
           'Raipur', 'Ranchi', 'Abu Dhabi', 'Sharjah', nan, 'Kanpur',
           'Mohali', 'Bengaluru'], dtype=object)




```python
import pickle
pickle.dump(pipe,open('pipe.pkl','wb'))
```


```python

```
